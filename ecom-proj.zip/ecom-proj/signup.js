document.getElementById("signup-form").addEventListener("submit", function (event) {
    event.preventDefault();

    const firstName = encodeURIComponent(document.getElementById("first-name").value);
    const lastName = encodeURIComponent(document.getElementById("last-name").value);
    const phone = encodeURIComponent(document.getElementById("phone").value);
    const email = encodeURIComponent(document.getElementById("email").value);
    const password = encodeURIComponent(document.getElementById("password").value);

    window.location.href = `details.html?firstName=${firstName}&lastName=${lastName}&phone=${phone}&email=${email}&password=${password}`;
});
function saveUserDetails(firstName, lastName, phone, email, password) {
    const userDetails = {
        firstName,
        lastName,
        phone,
        email,
        password,
    };

    const existingUsers = JSON.parse(localStorage.getItem("users") || "[]");
    existingUsers.push(userDetails);
    localStorage.setItem("users", JSON.stringify(existingUsers));
}

document.getElementById("signup-form").addEventListener("submit", function (event) {
    event.preventDefault();

    const firstName = encodeURIComponent(document.getElementById("first-name").value);
    const lastName = encodeURIComponent(document.getElementById("last-name").value);
    const phone = encodeURIComponent(document.getElementById("phone").value);
    const email = encodeURIComponent(document.getElementById("email").value);
    const password = encodeURIComponent(document.getElementById("password").value);


    saveUserDetails(firstName, lastName, phone, email, password);

    window.location.href = `details.html?firstName=${firstName}&lastName=${lastName}&phone=${phone}&email=${email}`;
});