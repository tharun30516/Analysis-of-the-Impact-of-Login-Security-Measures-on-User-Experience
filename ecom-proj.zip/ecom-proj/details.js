function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

document.getElementById("user-first-name").innerText = decodeURIComponent(getQueryParam("firstName"));
document.getElementById("user-last-name").innerText = decodeURIComponent(getQueryParam("lastName"));
document.getElementById("user-phone").innerText = decodeURIComponent(getQueryParam("phone"));
document.getElementById("user-email").innerText = decodeURIComponent(getQueryParam("email"));

