const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');
const rateLimit = require('express-rate-limit');

let ipCounts = new Map();

app.use(express.static(__dirname));

const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 10, // limit each IP to 10 requests per windowMs
    handler: (req, res, next) => {
        let ip = req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress.replace('::ffff:', '');
        if (ip === '::1') {
            ip = '127.0.0.1';
        }
        console.log(`IP: ${ip} is blocked due to too many requests.`);
        res.status(429).send('Too many requests from this IP, please try again later.');
    },
});

app.use(limiter);

app.get('/', (req, res) => {
    let ip = req.headers['x-forwarded-for'] || req.ip || req.connection.remoteAddress.replace('::ffff:', '');
    if (ip === '::1') {
        ip = '127.0.0.1';
    }
    let count = ipCounts.get(ip) || 0;
    count++;
    ipCounts.set(ip, count);

    console.log(`IP: ${ip} has ${count} requests`);

    res.sendFile(path.join(__dirname, 'login.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
